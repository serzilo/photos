var app = require('./app.js');

app.init();
