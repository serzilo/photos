var Backbone = require("../common/backboneFix.js");

var UserData = Backbone.Model.extend({

});

module.exports = new UserData();
