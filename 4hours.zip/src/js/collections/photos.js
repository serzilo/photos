var Backbone = require("../common/backboneFix.js");

var Photos = Backbone.Collection.extend({

});

module.exports = new Photos();
