var Backbone = require("backbone");
var $ = require('jquery');
var _ = require("underscore");

Backbone.$ = $;

window.$ = $;
window._ = _;

module.exports = Backbone;
