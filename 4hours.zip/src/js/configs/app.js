var data = {
    apiId: '5856047',
    appPermissions: '7'
};

module.exports = data;
